import { useState, useRef, useEffect } from "react";
import {
  Bell, Home, Users, BookOpen, BarChart2, User, Plus, Search,
  Filter, ChevronRight, Check, Clock, Mic, Upload, X, Star,
  Trophy, Download, ArrowLeft, Play, Volume2, LogOut, Settings,
  CheckCircle, Circle, AlertCircle, ChevronDown, Globe
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────

type Role = "orthophoniste" | "parent";
type Screen =
  | "login"
  | "ortho-dashboard"
  | "patients"
  | "patient-detail"
  | "exercise-create"
  | "parent-dashboard"
  | "parent-progress"
  | "ortho-progress";

interface Patient {
  id: number;
  nom: string;
  age: number;
  statut: "Actif" | "Archivé";
  progression: number;
  total: number;
  avatar: string;
}

interface Exercise {
  id: number;
  titre: string;
  statut: "terminé" | "assigné" | "non-assigné";
  dateAssignation: string;
  dateRealisation?: string;
  image?: string;
  instructions: string;
}

// ── Mock Data ───────────────────────────────────────────────────────────────

const patients: Patient[] = [
  { id: 1, nom: "Emma Martin", age: 6, statut: "Actif", progression: 4, total: 10, avatar: "EM" },
  { id: 2, nom: "Noah Dupont", age: 7, statut: "Actif", progression: 2, total: 8, avatar: "ND" },
  { id: 3, nom: "Léa Bernard", age: 5, statut: "Actif", progression: 7, total: 10, avatar: "LB" },
  { id: 4, nom: "Lucas Moreau", age: 8, statut: "Archivé", progression: 10, total: 10, avatar: "LM" },
  { id: 5, nom: "Chloé Petit", age: 6, statut: "Actif", progression: 1, total: 6, avatar: "CP" },
];

const exercisesOrtho: Exercise[] = [
  { id: 1, titre: "Son SH - Niveau 1", statut: "terminé", dateAssignation: "10 juil.", dateRealisation: "15 juil.", instructions: "Répéter 'chat', 'chapeau', 'cheval'" },
  { id: 2, titre: "Son R - Répétition", statut: "assigné", dateAssignation: "12 juil.", instructions: "Pratiquer le son R devant un miroir" },
  { id: 3, titre: "Son P - Souffle", statut: "assigné", dateAssignation: "14 juil.", instructions: "Souffler une bougie, répéter 'papa'" },
  { id: 4, titre: "Voyelles longues", statut: "terminé", dateAssignation: "5 juil.", dateRealisation: "8 juil.", instructions: "Étirer les sons A, E, I, O, U" },
  { id: 5, titre: "Son S - Sifflement", statut: "assigné", dateAssignation: "16 juil.", instructions: "Répéter 'soleil', 'sapin', 'sac'" },
  { id: 6, titre: "Son L - Langue", statut: "non-assigné", dateAssignation: "-", instructions: "Exercices de langue contre palais" },
];

const exercisesParent: Exercise[] = [
  { id: 1, titre: "Son SH", statut: "terminé", dateAssignation: "10 juil.", dateRealisation: "15 juil.", instructions: "Répétez 'chat', 'chapeau', 'cheval' avec votre enfant 5 fois.", image: "https://images.unsplash.com/photo-1555009393-f20bdb245c4d?w=300&h=200&fit=crop&auto=format" },
  { id: 2, titre: "Son R - Répétition", statut: "assigné", dateAssignation: "12 juil.", instructions: "Demandez à Emma de pratiquer le son R devant un miroir 3 fois par jour.", image: "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=300&h=200&fit=crop&auto=format" },
  { id: 3, titre: "Son P - Souffle", statut: "assigné", dateAssignation: "14 juil.", instructions: "Souffler une bougie à distance, répéter 'papa', 'pomme', 'pont'.", image: "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=300&h=200&fit=crop&auto=format" },
];

// ── Utils ───────────────────────────────────────────────────────────────────

const avatarColors = ["#4A90D9", "#6EC6A0", "#F5A623", "#9B59B6", "#E74C3C"];
const getAvatarColor = (initials: string) => avatarColors[initials.charCodeAt(0) % avatarColors.length];

// ── Components ──────────────────────────────────────────────────────────────

function Avatar({ initials, size = 40 }: { initials: string; size?: number }) {
  return (
    <div
      className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
      style={{ width: size, height: size, backgroundColor: getAvatarColor(initials), fontSize: size * 0.35 }}
    >
      {initials}
    </div>
  );
}

function BottomNav({
  role,
  active,
  onNavigate,
}: {
  role: Role;
  active: string;
  onNavigate: (s: Screen) => void;
}) {
  const orthoItems = [
    { icon: Home, label: "Accueil", screen: "ortho-dashboard" as Screen },
    { icon: Users, label: "Patients", screen: "patients" as Screen },
    { icon: BookOpen, label: "Exercices", screen: "exercise-create" as Screen },
    { icon: BarChart2, label: "Rapports", screen: "ortho-progress" as Screen },
    { icon: User, label: "Profil", screen: "ortho-dashboard" as Screen },
  ];
  const parentItems = [
    { icon: Home, label: "Accueil", screen: "parent-dashboard" as Screen },
    { icon: BookOpen, label: "Exercices", screen: "parent-dashboard" as Screen },
    { icon: BarChart2, label: "Progrès", screen: "parent-progress" as Screen },
    { icon: User, label: "Profil", screen: "parent-dashboard" as Screen },
  ];
  const items = role === "orthophoniste" ? orthoItems : parentItems;
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-border flex justify-around items-center h-16 z-50 max-w-[430px] mx-auto" style={{ boxShadow: "0 -2px 12px rgba(0,0,0,0.06)" }}>
      {items.map((item) => {
        const isActive = active === item.screen;
        return (
          <button
            key={item.label}
            onClick={() => onNavigate(item.screen)}
            className="flex flex-col items-center gap-0.5 px-3 py-1 transition-all"
            style={{ color: isActive ? "#4A90D9" : "#718096" }}
          >
            <item.icon size={20} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3500);
    return () => clearTimeout(t);
  }, [onClose]);
  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-4 duration-300">
      <div className="bg-[#48BB78] text-white px-5 py-3 rounded-2xl shadow-lg flex items-center gap-2 text-sm font-medium whitespace-nowrap">
        <CheckCircle size={16} />
        {message}
      </div>
    </div>
  );
}

// ── Screen 1 — Connexion ────────────────────────────────────────────────────

function LoginScreen({ onLogin }: { onLogin: (role: Role) => void }) {
  const [role, setRole] = useState<Role>("orthophoniste");
  const [lang, setLang] = useState("FR");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showLang, setShowLang] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "linear-gradient(135deg, #4A90D9 0%, #6EC6A0 100%)" }} onClick={() => setShowLang(false)}>
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center shadow-lg mb-4" style={{ boxShadow: "0 8px 32px rgba(74,144,217,0.3)" }}>
            <span className="text-3xl font-bold" style={{ color: "#4A90D9", fontFamily: "Poppins, sans-serif" }}>O</span>
            <div className="absolute w-5 h-5 rounded-full bg-[#F5A623] -mt-8 ml-8 flex items-center justify-center" style={{ fontSize: 10, color: "white" }}>💬</div>
          </div>
          <h1 className="text-white text-2xl font-bold" style={{ fontFamily: "Poppins, sans-serif", textShadow: "0 2px 8px rgba(0,0,0,0.15)" }}>OrthoVoix</h1>
          <p className="text-white/80 text-sm mt-1">Application d'orthophonie</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl p-6 shadow-2xl">
          {/* Language selector */}
          <div className="flex justify-end mb-4 relative">
            <button onClick={() => setShowLang(!showLang)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors border border-border rounded-xl px-3 py-1.5">
              <Globe size={14} />
              {lang}
              <ChevronDown size={12} />
            </button>
            {showLang && (
              <div className="absolute top-10 right-0 bg-white border border-border rounded-xl shadow-lg z-10 overflow-hidden">
                {["FR", "EN", "AR"].map((l) => (
                  <button key={l} onClick={() => { setLang(l); setShowLang(false); }} className={`block w-full text-left px-4 py-2 text-sm hover:bg-muted transition-colors ${lang === l ? "text-primary font-medium" : "text-foreground"}`}>{l}</button>
                ))}
              </div>
            )}
          </div>

          {/* Role selector */}
          <div className="flex rounded-2xl bg-muted p-1 mb-5">
            {(["orthophoniste", "parent"] as Role[]).map((r) => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className="flex-1 py-2 rounded-xl text-sm font-medium transition-all duration-200"
                style={{
                  background: role === r ? "#4A90D9" : "transparent",
                  color: role === r ? "#fff" : "#718096",
                  boxShadow: role === r ? "0 2px 8px rgba(74,144,217,0.3)" : "none",
                }}
              >
                {r === "orthophoniste" ? "Orthophoniste" : "Parent"}
              </button>
            ))}
          </div>

          {/* Fields */}
          <div className="space-y-3 mb-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Adresse email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="dr.sarah@ortho.fr"
                className="w-full bg-muted rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition-all"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Mot de passe</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-muted rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition-all"
              />
            </div>
          </div>

          <div className="flex justify-end mb-5">
            <button className="text-xs text-primary font-medium hover:underline">Mot de passe oublié ?</button>
          </div>

          <button
            onClick={() => onLogin(role)}
            className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm transition-all duration-150 active:scale-95"
            style={{ background: "linear-gradient(135deg, #4A90D9, #6EC6A0)", boxShadow: "0 4px 16px rgba(74,144,217,0.4)", fontFamily: "Poppins, sans-serif" }}
          >
            Se connecter
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Screen 2 — Dashboard Orthophoniste ─────────────────────────────────────

function OrthoDashboard({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const activite = [
    { nom: "Emma Martin", action: "a terminé", exercice: "Son SH", statut: "✅", temps: "il y a 2h", avatar: "EM" },
    { nom: "Noah Dupont", action: "en attente", exercice: "Son R", statut: "⏳", temps: "il y a 5h", avatar: "ND" },
    { nom: "Léa Bernard", action: "a terminé", exercice: "Voyelles longues", statut: "✅", temps: "hier", avatar: "LB" },
  ];
  const stats = [
    { label: "Total patients", val: 12, color: "#4A90D9", bg: "#EBF4FF" },
    { label: "En attente", val: 8, color: "#F5A623", bg: "#FFFAF0" },
    { label: "Terminés", val: 24, color: "#48BB78", bg: "#F0FFF4" },
  ];
  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="px-5 pt-12 pb-5" style={{ background: "linear-gradient(135deg, #4A90D9 0%, #6EC6A0 100%)" }}>
        <div className="flex items-center justify-between mb-1">
          <div>
            <p className="text-white/80 text-sm">Bonjour,</p>
            <h1 className="text-white text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>Dr. Sarah 👋</h1>
          </div>
          <div className="flex items-center gap-3">
            <button className="relative">
              <Bell size={22} className="text-white" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#F5A623] rounded-full text-[9px] text-white flex items-center justify-center font-bold">3</span>
            </button>
            <Avatar initials="DS" size={38} />
          </div>
        </div>
      </div>

      <div className="px-5 -mt-2">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {stats.map((s) => (
            <div key={s.label} className="bg-white rounded-2xl p-3 text-center shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              <div className="text-2xl font-bold mb-0.5" style={{ color: s.color, fontFamily: "Poppins, sans-serif" }}>{s.val}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Quick actions */}
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Actions rapides</h2>
        <div className="grid grid-cols-2 gap-3 mb-5">
          {[
            { icon: "👤", label: "Ajouter Patient", color: "#EBF4FF", screen: "patients" as Screen },
            { icon: "📝", label: "Créer Exercice", color: "#F0FFF4", screen: "exercise-create" as Screen },
            { icon: "📋", label: "Mes Patients", color: "#FFFAF0", screen: "patients" as Screen },
            { icon: "📊", label: "Rapports", color: "#FFF5F5", screen: "ortho-progress" as Screen },
          ].map((a) => (
            <button
              key={a.label}
              onClick={() => onNavigate(a.screen)}
              className="flex items-center gap-3 p-4 rounded-2xl bg-white shadow-sm active:scale-95 transition-all text-left"
              style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}
            >
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: a.color }}>{a.icon}</div>
              <span className="text-sm font-medium text-foreground">{a.label}</span>
            </button>
          ))}
        </div>

        {/* Activité */}
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Activité récente</h2>
        <div className="space-y-3">
          {activite.map((a, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              <Avatar initials={a.avatar} size={40} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  <span className="font-semibold">{a.nom}</span> {a.action} <span className="text-primary">'{a.exercice}'</span> {a.statut}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">{a.temps}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Screen 3 — Liste des Patients ──────────────────────────────────────────

function PatientList({ onNavigate, onSelectPatient }: { onNavigate: (s: Screen) => void; onSelectPatient: (p: Patient) => void }) {
  const [search, setSearch] = useState("");
  const [filtre, setFiltre] = useState<"Tous" | "Actif" | "Archivé">("Tous");

  const filtered = patients.filter(
    (p) =>
      (filtre === "Tous" || p.statut === filtre) &&
      p.nom.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="px-5 pt-12 pb-4 bg-white border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>Mes Patients</h1>
          <button className="flex items-center gap-1.5 bg-primary text-white px-4 py-2 rounded-2xl text-sm font-medium active:scale-95 transition-all">
            <Plus size={16} />
            Ajouter
          </button>
        </div>
        {/* Search */}
        <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2.5 mb-3">
          <Search size={16} className="text-muted-foreground flex-shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un patient..."
            className="flex-1 bg-transparent text-sm outline-none"
          />
        </div>
        {/* Filters */}
        <div className="flex gap-2">
          {(["Tous", "Actif", "Archivé"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFiltre(f)}
              className="px-4 py-1.5 rounded-2xl text-xs font-medium transition-all"
              style={{
                background: filtre === f ? "#4A90D9" : "#EDF2F7",
                color: filtre === f ? "#fff" : "#718096",
              }}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 pt-4 space-y-3">
        {filtered.map((p) => (
          <button
            key={p.id}
            onClick={() => { onSelectPatient(p); onNavigate("patient-detail"); }}
            className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm active:scale-[0.98] transition-all text-left"
            style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}
          >
            <Avatar initials={p.avatar} size={48} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="font-semibold text-sm">{p.nom}</span>
                <span
                  className="text-[10px] font-medium px-2 py-0.5 rounded-full"
                  style={{
                    background: p.statut === "Actif" ? "#F0FFF4" : "#F7FAFC",
                    color: p.statut === "Actif" ? "#48BB78" : "#718096",
                  }}
                >
                  {p.statut}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{p.age} ans</p>
              {/* Progress bar */}
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${(p.progression / p.total) * 100}%`, background: "linear-gradient(90deg, #4A90D9, #6EC6A0)" }}
                  />
                </div>
                <span className="text-[10px] text-muted-foreground font-medium">{p.progression}/{p.total}</span>
              </div>
            </div>
            <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground text-sm">Aucun patient trouvé</div>
        )}
      </div>
    </div>
  );
}

// ── Screen 3b — Détail Patient ─────────────────────────────────────────────

function PatientDetail({ patient, onNavigate }: { patient: Patient | null; onNavigate: (s: Screen) => void }) {
  if (!patient) return null;
  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="px-5 pt-12 pb-4 bg-white border-b border-border">
        <button onClick={() => onNavigate("patients")} className="flex items-center gap-2 text-primary mb-4 text-sm font-medium">
          <ArrowLeft size={18} /> Retour
        </button>
        <div className="flex items-center gap-4">
          <Avatar initials={patient.avatar} size={56} />
          <div>
            <h1 className="text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>{patient.nom}</h1>
            <p className="text-sm text-muted-foreground">{patient.age} ans • {patient.statut}</p>
          </div>
        </div>
        <div className="mt-4 flex items-center gap-2">
          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
            <div className="h-full rounded-full" style={{ width: `${(patient.progression / patient.total) * 100}%`, background: "linear-gradient(90deg, #4A90D9, #6EC6A0)" }} />
          </div>
          <span className="text-xs text-muted-foreground font-medium">{patient.progression}/{patient.total} exercices</span>
        </div>
        <button
          onClick={() => onNavigate("exercise-create")}
          className="mt-4 w-full py-3 rounded-2xl bg-secondary text-white font-semibold text-sm active:scale-95 transition-all"
        >
          ➕ Assigner un exercice
        </button>
      </div>
      <div className="px-5 pt-4">
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Exercices assignés</h2>
        <div className="space-y-2.5">
          {exercisesOrtho.slice(0, 5).map((ex) => (
            <div key={ex.id} className="bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              <div className="w-8 h-8 rounded-xl flex items-center justify-center text-sm flex-shrink-0"
                style={{ background: ex.statut === "terminé" ? "#F0FFF4" : ex.statut === "assigné" ? "#FFFAF0" : "#F7FAFC" }}>
                {ex.statut === "terminé" ? "🟢" : ex.statut === "assigné" ? "🟡" : "⚪"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{ex.titre}</p>
                <p className="text-xs text-muted-foreground">Assigné le {ex.dateAssignation}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Screen 4 — Création d'Exercice ─────────────────────────────────────────

function ExerciseCreate({ onNavigate, onShowToast }: { onNavigate: (s: Screen) => void; onShowToast: (m: string) => void }) {
  const [step, setStep] = useState(1);
  const [titre, setTitre] = useState("");
  const [mot, setMot] = useState("");
  const [instructions, setInstructions] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [recording, setRecording] = useState(false);
  const [selected, setSelected] = useState<number[]>([1, 3]);

  const canNext1 = titre.trim() && mot.trim();

  const handleCreate = () => {
    onShowToast("Exercice créé et assigné à 3 patients ✅");
    onNavigate("ortho-dashboard");
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="px-5 pt-12 pb-4 bg-white border-b border-border">
        <button onClick={() => onNavigate("ortho-dashboard")} className="flex items-center gap-2 text-primary mb-3 text-sm font-medium">
          <ArrowLeft size={18} /> Retour
        </button>
        <h1 className="text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>Nouvel exercice</h1>
        {/* Steps */}
        <div className="flex items-center gap-2 mt-3">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all"
                style={{ background: step >= s ? "#4A90D9" : "#EDF2F7", color: step >= s ? "#fff" : "#718096" }}>
                {step > s ? <Check size={12} /> : s}
              </div>
              {s < 3 && <div className="w-8 h-0.5 rounded-full" style={{ background: step > s ? "#4A90D9" : "#EDF2F7" }} />}
            </div>
          ))}
          <span className="text-xs text-muted-foreground ml-1">
            {step === 1 ? "Contenu" : step === 2 ? "Médias" : "Attribution"}
          </span>
        </div>
      </div>

      <div className="px-5 pt-5">
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Titre de l'exercice *</label>
              <input value={titre} onChange={(e) => setTitre(e.target.value)} placeholder="Ex: Son SH - Niveau 1"
                className="w-full bg-white border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition-all" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Mot / Phrase cible *</label>
              <input value={mot} onChange={(e) => setMot(e.target.value)} placeholder="Ex: chapeau, chat, cheval"
                className="w-full bg-white border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition-all" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Instructions pour le parent</label>
              <textarea value={instructions} onChange={(e) => setInstructions(e.target.value)}
                placeholder="Expliquez comment réaliser l'exercice à la maison..."
                rows={4}
                className="w-full bg-white border border-border rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 transition-all resize-none" />
            </div>
            <button onClick={() => setStep(2)} disabled={!canNext1}
              className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm active:scale-95 transition-all disabled:opacity-50"
              style={{ background: canNext1 ? "linear-gradient(135deg, #4A90D9, #6EC6A0)" : undefined, backgroundColor: canNext1 ? undefined : "#CBD5E0" }}>
              Suivant →
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            {/* Image drag-drop */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-2 block">Image illustrative</label>
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => { e.preventDefault(); setDragOver(false); }}
                className="w-full h-36 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 transition-all cursor-pointer"
                style={{ borderColor: dragOver ? "#4A90D9" : "#CBD5E0", background: dragOver ? "#EBF4FF" : "#F7FAFC" }}
              >
                <Upload size={28} className="text-muted-foreground" />
                <p className="text-sm text-muted-foreground text-center">Glisser-déposer une image<br /><span className="text-primary text-xs">ou cliquer pour parcourir</span></p>
              </div>
            </div>
            {/* Audio */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-2 block">Audio de démonstration</label>
              <div className="flex gap-3">
                <button
                  onClick={() => setRecording(!recording)}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-medium transition-all active:scale-95"
                  style={{ background: recording ? "#FFF5F5" : "#F0FFF4", color: recording ? "#FC8181" : "#48BB78", border: `1.5px solid ${recording ? "#FC8181" : "#48BB78"}` }}
                >
                  <Mic size={18} />
                  {recording ? "Arrêter" : "Enregistrer"}
                </button>
                <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-sm font-medium bg-white border border-border active:scale-95 transition-all">
                  <Upload size={18} className="text-muted-foreground" />
                  Importer
                </button>
              </div>
              {recording && (
                <div className="mt-2 flex items-center gap-2 px-4 py-2 bg-red-50 rounded-xl">
                  <div className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                  <span className="text-xs text-red-500 font-medium">Enregistrement en cours...</span>
                </div>
              )}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(1)} className="flex-1 py-3 rounded-2xl border border-border text-sm font-medium active:scale-95 transition-all">← Retour</button>
              <button onClick={() => setStep(3)} className="flex-1 py-3 rounded-2xl text-white text-sm font-semibold active:scale-95 transition-all" style={{ background: "linear-gradient(135deg, #4A90D9, #6EC6A0)" }}>Suivant →</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Assigner à des patients</h3>
            <div className="space-y-2.5">
              {patients.filter((p) => p.statut === "Actif").map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelected((prev) => prev.includes(p.id) ? prev.filter((x) => x !== p.id) : [...prev, p.id])}
                  className="w-full bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm active:scale-[0.98] transition-all"
                  style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)", border: selected.includes(p.id) ? "2px solid #4A90D9" : "2px solid transparent" }}
                >
                  <Avatar initials={p.avatar} size={40} />
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{p.nom}</p>
                    <p className="text-xs text-muted-foreground">{p.age} ans</p>
                  </div>
                  <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: selected.includes(p.id) ? "#4A90D9" : "#EDF2F7" }}>
                    {selected.includes(p.id) && <Check size={12} className="text-white" />}
                  </div>
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep(2)} className="flex-1 py-3 rounded-2xl border border-border text-sm font-medium active:scale-95 transition-all">← Retour</button>
              <button onClick={handleCreate} disabled={selected.length === 0}
                className="flex-1 py-3 rounded-2xl text-white text-sm font-semibold active:scale-95 transition-all disabled:opacity-50"
                style={{ background: "linear-gradient(135deg, #4A90D9, #6EC6A0)" }}>
                Créer et assigner
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Screen 5 — Dashboard Parent ────────────────────────────────────────────

function ParentDashboard({ onNavigate, onShowToast }: { onNavigate: (s: Screen) => void; onShowToast: (m: string) => void }) {
  const [done, setDone] = useState<number[]>([1]);
  const [playingId, setPlayingId] = useState<number | null>(null);

  const handleDone = (id: number) => {
    setDone((prev) => [...prev, id]);
    onShowToast("Super travail ! Exercice terminé 🌟");
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="px-5 pt-12 pb-5" style={{ background: "linear-gradient(135deg, #6EC6A0 0%, #4A90D9 100%)" }}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-white/80 text-sm">Bonjour,</p>
            <h1 className="text-white text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>David 👋</h1>
            <p className="text-white/90 text-sm mt-0.5">Les exercices d'Emma</p>
          </div>
          <Avatar initials="DP" size={44} />
        </div>
        {/* Progress ring simplified */}
        <div className="mt-4 bg-white/20 rounded-2xl p-3 flex items-center gap-3">
          <div className="w-12 h-12 rounded-full border-4 border-white/60 flex items-center justify-center">
            <span className="text-white text-xs font-bold">{done.length}/{exercisesParent.length}</span>
          </div>
          <div>
            <p className="text-white font-semibold text-sm">Progression de la semaine</p>
            <p className="text-white/80 text-xs">{done.length} exercice{done.length > 1 ? "s" : ""} terminé{done.length > 1 ? "s" : ""} sur {exercisesParent.length}</p>
          </div>
        </div>
      </div>

      <div className="px-5 pt-4">
        {/* Active exercises */}
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>À faire</h2>
        <div className="space-y-4">
          {exercisesParent.filter((ex) => !done.includes(ex.id)).map((ex) => (
            <div key={ex.id} className="bg-white rounded-2xl overflow-hidden shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              {ex.image && (
                <img src={ex.image} alt={ex.titre} className="w-full h-36 object-cover" />
              )}
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-base" style={{ fontFamily: "Poppins, sans-serif" }}>{ex.titre}</h3>
                  <button
                    onClick={() => setPlayingId(playingId === ex.id ? null : ex.id)}
                    className="w-10 h-10 rounded-full flex items-center justify-center transition-all active:scale-90"
                    style={{ background: playingId === ex.id ? "#4A90D9" : "#EBF4FF" }}
                  >
                    {playingId === ex.id ? <Volume2 size={18} className="text-white" /> : <Play size={18} className="text-primary" />}
                  </button>
                </div>
                <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{ex.instructions}</p>
                <button
                  onClick={() => handleDone(ex.id)}
                  className="w-full py-3 rounded-2xl text-white font-semibold text-sm active:scale-95 transition-all"
                  style={{ background: "linear-gradient(135deg, #48BB78, #6EC6A0)" }}
                >
                  ✓ Marquer comme terminé
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Done exercises */}
        {done.length > 0 && (
          <>
            <h2 className="text-base font-semibold mt-5 mb-3 flex items-center gap-2" style={{ fontFamily: "Poppins, sans-serif" }}>
              Terminés <span className="text-sm font-normal text-muted-foreground">— Super travail, Emma ! 🌟</span>
            </h2>
            <div className="space-y-2.5">
              {exercisesParent.filter((ex) => done.includes(ex.id)).map((ex) => (
                <div key={ex.id} className="bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
                  <div className="w-9 h-9 rounded-full bg-[#F0FFF4] flex items-center justify-center flex-shrink-0">
                    <CheckCircle size={18} className="text-[#48BB78]" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{ex.titre}</p>
                    <p className="text-xs text-muted-foreground">{ex.dateRealisation || "Aujourd'hui"}</p>
                  </div>
                  <span className="text-lg">✅</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Screen 6 — Progrès Parent ──────────────────────────────────────────────

function ParentProgress({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const total = 10;
  const done = 6;
  const pct = (done / total) * 100;
  const r = 54;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;

  const badges = [
    { icon: "⭐", label: "Première étoile", desc: "1er exercice terminé", unlocked: true },
    { icon: "🏆", label: "Champion", desc: "5 exercices terminés", unlocked: true },
    { icon: "🌟", label: "Superstar", desc: "10 exercices terminés", unlocked: false },
    { icon: "🎯", label: "Précision", desc: "3 jours consécutifs", unlocked: true },
  ];

  const historique = [
    { icon: "🏆", titre: "Son SH", date: "15 juillet" },
    { icon: "⭐", titre: "Voyelles longues", date: "8 juillet" },
    { icon: "🏆", titre: "Son P", date: "3 juillet" },
    { icon: "⭐", titre: "Son B", date: "28 juin" },
    { icon: "🏆", titre: "Respiration", date: "20 juin" },
    { icon: "⭐", titre: "Sons nasaux", date: "15 juin" },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="px-5 pt-12 pb-4 bg-white border-b border-border">
        <h1 className="text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>Progrès d'Emma 🌟</h1>
      </div>

      <div className="px-5 pt-5">
        {/* Donut ring */}
        <div className="bg-white rounded-3xl p-6 flex flex-col items-center shadow-sm mb-5" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
          <div className="relative mb-3">
            <svg width={130} height={130} viewBox="0 0 130 130">
              <circle cx={65} cy={65} r={r} fill="none" stroke="#EDF2F7" strokeWidth={12} />
              <circle cx={65} cy={65} r={r} fill="none"
                stroke="#4A90D9" strokeWidth={12}
                strokeDasharray={`${dash} ${circ - dash}`}
                strokeDashoffset={circ / 4}
                strokeLinecap="round"
                style={{ transition: "stroke-dasharray 1s ease" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold text-foreground" style={{ fontFamily: "Poppins, sans-serif" }}>{done}/{total}</span>
              <span className="text-[10px] text-muted-foreground">exercices</span>
            </div>
          </div>
          <p className="text-base font-semibold text-center" style={{ fontFamily: "Poppins, sans-serif" }}>{done} exercices sur {total} terminés !</p>
          <p className="text-sm text-[#48BB78] font-medium mt-1">Continue comme ça ! 💪</p>
        </div>

        {/* Badges */}
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Badges obtenus</h2>
        <div className="grid grid-cols-2 gap-3 mb-5">
          {badges.map((b, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 flex items-center gap-3 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)", opacity: b.unlocked ? 1 : 0.4 }}>
              <div className="text-2xl">{b.icon}</div>
              <div>
                <p className="text-xs font-semibold">{b.label}</p>
                <p className="text-[10px] text-muted-foreground">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Historique */}
        <h2 className="text-base font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Historique</h2>
        <div className="space-y-2.5">
          {historique.map((h, i) => (
            <div key={i} className="bg-white rounded-2xl p-3.5 flex items-center gap-3 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              <span className="text-xl">{h.icon}</span>
              <div className="flex-1">
                <p className="text-sm font-medium">{h.titre}</p>
              </div>
              <p className="text-xs text-muted-foreground">{h.date}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Screen 7 — Progrès Orthophoniste ──────────────────────────────────────

function OrthoProgress({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const total = 10;
  const done = 6;
  const rate = Math.round((done / total) * 100);
  const [selected, setSelected] = useState(0);

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="px-5 pt-12 pb-4 bg-white border-b border-border">
        <h1 className="text-xl font-bold" style={{ fontFamily: "Poppins, sans-serif" }}>Progrès patients</h1>
        {/* Patient selector */}
        <div className="flex gap-2 mt-3 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {patients.filter((p) => p.statut === "Actif").map((p, i) => (
            <button
              key={p.id}
              onClick={() => setSelected(i)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-2xl flex-shrink-0 text-xs font-medium transition-all"
              style={{
                background: selected === i ? "#4A90D9" : "#EDF2F7",
                color: selected === i ? "#fff" : "#718096",
              }}
            >
              <span>{p.avatar}</span>
              {p.nom.split(" ")[0]}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 pt-4">
        {/* Patient selected */}
        <div className="bg-white rounded-2xl p-4 flex items-center gap-3 mb-4 shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
          <Avatar initials={patients[selected].avatar} size={48} />
          <div>
            <p className="font-semibold">{patients[selected].nom}</p>
            <p className="text-xs text-muted-foreground">{patients[selected].age} ans</p>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            { label: "Assignés", val: total, color: "#4A90D9" },
            { label: "Terminés", val: done, color: "#48BB78" },
            { label: "Taux", val: `${rate}%`, color: "#F5A623" },
          ].map((s) => (
            <div key={s.label} className="bg-white rounded-2xl p-3 text-center shadow-sm" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
              <div className="text-xl font-bold" style={{ color: s.color, fontFamily: "Poppins, sans-serif" }}>{s.val}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Exercises table */}
        <h2 className="text-sm font-semibold mb-3" style={{ fontFamily: "Poppins, sans-serif" }}>Détail des exercices</h2>
        <div className="bg-white rounded-2xl overflow-hidden shadow-sm mb-4" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
          <div className="grid grid-cols-4 text-[10px] font-semibold text-muted-foreground px-4 py-2.5 border-b border-border bg-muted">
            <span className="col-span-2">Exercice</span>
            <span>Assigné</span>
            <span>Statut</span>
          </div>
          {exercisesOrtho.map((ex) => (
            <div key={ex.id} className="grid grid-cols-4 items-center px-4 py-3 border-b border-border last:border-0">
              <div className="col-span-2 min-w-0">
                <p className="text-xs font-medium truncate">{ex.titre}</p>
                {ex.dateRealisation && <p className="text-[10px] text-muted-foreground">{ex.dateRealisation}</p>}
              </div>
              <span className="text-[10px] text-muted-foreground">{ex.dateAssignation}</span>
              <div className="flex items-center gap-1">
                {ex.statut === "terminé" ? (
                  <span className="flex items-center gap-0.5 text-[10px] font-medium text-[#48BB78]"><CheckCircle size={10} /> Fait</span>
                ) : ex.statut === "assigné" ? (
                  <span className="flex items-center gap-0.5 text-[10px] font-medium text-[#F5A623]"><Clock size={10} /> Attente</span>
                ) : (
                  <span className="flex items-center gap-0.5 text-[10px] font-medium text-muted-foreground"><Circle size={10} /> —</span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Export */}
        <button className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl border-2 border-primary text-primary font-semibold text-sm active:scale-95 transition-all bg-white">
          <Download size={18} />
          Exporter en PDF
        </button>
      </div>
    </div>
  );
}

// ── Root App ────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [role, setRole] = useState<Role>("orthophoniste");
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const handleLogin = (r: Role) => {
    setRole(r);
    setScreen(r === "orthophoniste" ? "ortho-dashboard" : "parent-dashboard");
  };

  const showToast = (msg: string) => setToast(msg);

  const navScreens: Screen[] = role === "orthophoniste"
    ? ["ortho-dashboard", "patients", "patient-detail", "exercise-create", "ortho-progress"]
    : ["parent-dashboard", "parent-progress"];

  const isNavScreen = navScreens.includes(screen);

  return (
    <div className="w-full min-h-screen bg-background" style={{ fontFamily: "Inter, sans-serif" }}>
      {/* Constrain to mobile width, centered */}
      <div className="max-w-[430px] mx-auto relative bg-background min-h-screen">
        {toast && <Toast message={toast} onClose={() => setToast(null)} />}

        {screen === "login" && <LoginScreen onLogin={handleLogin} />}
        {screen === "ortho-dashboard" && <OrthoDashboard onNavigate={setScreen} />}
        {screen === "patients" && <PatientList onNavigate={setScreen} onSelectPatient={setSelectedPatient} />}
        {screen === "patient-detail" && <PatientDetail patient={selectedPatient} onNavigate={setScreen} />}
        {screen === "exercise-create" && <ExerciseCreate onNavigate={setScreen} onShowToast={showToast} />}
        {screen === "parent-dashboard" && <ParentDashboard onNavigate={setScreen} onShowToast={showToast} />}
        {screen === "parent-progress" && <ParentProgress onNavigate={setScreen} />}
        {screen === "ortho-progress" && <OrthoProgress onNavigate={setScreen} />}

        {isNavScreen && screen !== "login" && (
          <BottomNav role={role} active={screen} onNavigate={setScreen} />
        )}
      </div>
    </div>
  );
}
